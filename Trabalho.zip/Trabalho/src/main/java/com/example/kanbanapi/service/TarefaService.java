package com.example.kanbanapi.service;

import com.example.kanbanapi.model.Tarefa;
import com.example.kanbanapi.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TarefaService {

    @Autowired
    private TarefaRepository tarefaRepository;

    public Tarefa criarTarefa(Tarefa tarefa) {
        return tarefaRepository.save(tarefa);
    }

    public List<Tarefa> listarTarefas() {
        return tarefaRepository.findAll();
    }

    public Tarefa moverTarefa(Long id) {
        Tarefa tarefa = tarefaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Tarefa não encontrada"));
        switch (tarefa.getStatus()) {
            case "A Fazer":
                tarefa.setStatus("Em Progresso");
                break;
            case "Em Progresso":
                tarefa.setStatus("Concluído");
                break;
            default:
                throw new RuntimeException("Tarefa já concluída");
        }
        return tarefaRepository.save(tarefa);
    }

    public void excluirTarefa(Long id) {
        tarefaRepository.deleteById(id);
    }
}